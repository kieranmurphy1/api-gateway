var fs = require('fs');
const jwt = require('jsonwebtoken');
var privateKEY  = fs.readFileSync('/etc/nginx/private.key', 'utf8');
var publicKEY  = fs.readFileSync('/etc/nginx/public.key', 'utf8');

// Parse a JWT into a JSON Object and extract the claim 'user_name'.
module.exports = function verifyjwt(r) {
    var payload = {
        data1: "Data 1",
        data2: "Data 2",
        data3: "Data 3",
        data4: "Data 4",
    };
    var i  = 'Mysoft corp';   
    var s  = 'some@user.com';   
    var a  = 'http://mysoftcorp.in';
    var signOptions = {
        issuer:  i,
        subject:  s,
        audience:  a,
        expiresIn:  "12h",
        algorithm:  "RS256"   // RSASSA [ "RS256", "RS384", "RS512" ]
    };
    var token = jwt.sign(payload, privateKEY, signOptions);
    console.log("Token :" + token);
    r.log("ntrospectAccessToken.jwt() Token :" + token);

    var token;
    var parts = r.headersIn.authorization.split(' ');
    r.log("introspectAccessToken.jwt(): Authorization header =  " + r.headersIn.authorization);
    if (parts.length === 2) {
        var scheme = parts[0];
        var credentials = parts[1];
        if (/^Bearer$/i.test(scheme)) {
            token = credentials;
        } else {
            r.return(403, "Authorization JWT header missing Bearer label");
            r.log("introspectAccessToken.jwt(): 403 Error - Authorization JWT header missing Bearer label");
        }
    } else if (parts.length === 1) {
        token = parts[0];
    } else {
        r.return(403, "Authorization JWT header has incorrect number of elements");
        r.log("introspectAccessToken.jwt(): 403 Error - Authorization JWT header has incorrect number of elements");
    }

    var response = JSON.parse(token);
    r.log("introspectAccessToken.jwt() - parsing a JWT");

    if (response.active) {
        // Convert all members of the response into response headers
        for (var p in response) {
            if (!response.hasOwnProperty(p)) continue;
            r.log("OAuth2 Token-" + p + ": " + response[p]);
            r.headersOut['Token-' + p] = response[p];
        }
        r.status = 204;
    //    r.sendHeader();
        r.return(200, "testtoken");
        r.finish();
    } else {
        r.return(401);
    }
}
//=======================