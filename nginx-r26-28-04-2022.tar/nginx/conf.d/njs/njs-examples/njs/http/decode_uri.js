function dec_foo(r) {
    return decodeURIComponent(r.args.foo);
}

export default {dec_foo};
