function hello(r) {
    var name = "Kieran";
    r.return(200, "Hello world from " + name + " ! \n");
}

export default {hello}