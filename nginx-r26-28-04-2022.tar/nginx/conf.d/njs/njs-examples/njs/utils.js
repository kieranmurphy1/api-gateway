function version(r) {
    r.return(200, njs.version);
}

function tokenFromHeader(r) {
    var token;
    var parts = r.headersIn.authorization.split(' ');
    if (parts.length === 2) {
        var scheme = parts[0];
        var credentials = parts[1];
        if (/^Bearer$/i.test(scheme)) {
            token = credentials;
            r.headersOut.tokenOAuth = credentials;
            r.return(200,token);
        } else {r.return(200, "Authorization header missing Bearer label")}
    } else {r.return(200, "Authorization header does not have 2 parts")}
    //var token = r.headersIn.authorization.replace('Bearer ', '');
}

export default {version, tokenFromHeader}