local cjson = require "cjson";
local json = require "json";

local log_file = require "logging.file";
local logger = log_file("/tmp/Lua-Test-%s.log", "%Y-%m-%d");

logger:info("Lua HTTP Resty test START");

-- Single-shot requests use the `request_uri` interface.
-- The `res` table contains the expected `status`, `headers` and `body` fields.
local httpc = require("resty.http").new();
local status;
local length;
local body;
local res1, err1 = httpc:request_uri("http://127.0.0.1:8080/metrics", {
     method = "GET",
     headers = {
         ["Content-Type"] = "application/x-www-form-urlencoded",
     },
 });

if res1.status then
  status = res1.status;
  length = res1.headers["Content-Length"];
  body   = res1.body;
  logger:info("Lua HTTP Resty request succeeded- " .. status);
  logger:info("Lua HTTP Resty request succeeded- " .. body);
else
  ngx.log(ngx.ERR, "Lua HTTP Resty request failed: ", err1);
  logger:info("Lua HTTP Resty request failed - " .. status);
end 
-- At this point, the entire request / response is complete and the connection
-- will be closed or back on the connection pool.


-- local sampleJson = [[{"age":"23","testArray":{"array":[8,9,11,14,25]},"name":"Pat Barry"}]];
-- local sampleJson = { true, { foo = "bar" } };
-- local json = cjson.encode(sampleJson);
local sampleJson = '{"name":"kieran","job":"architect"}';
local json1 = json.encode(sampleJson);
local json2 = cjson.encode(sampleJson);
local json_stripped1 = string.gsub(json2, [[\"]], [[]]);
local json_stripped2 = string.gsub(json_stripped1, [["]], [[]]);
local lua_table = cjson.decode(sampleJson);

-- ngx.log(ngx.NOTICE, 'Lua Logger NOTICE: json1 = ', json1);
-- ngx.log(ngx.NOTICE, 'Lua Logger NOTICE: json1 = ', json1);
-- ngx.log(ngx.NOTICE, 'Lua Logger NOTICE: json2 = ', json2);
-- ngx.log(ngx.NOTICE, 'Lua Logger NOTICE: json_stripped1 = ', json_stripped1);
-- ngx.log(ngx.NOTICE, 'Lua Logger NOTICE: json_stripped2 = ', json_stripped2);
-- ngx.log(ngx.NOTICE, 'Lua Logger NOTICE: lua_table[name] = ', lua_table["name"]);

logger:info("Lua test START");

local res = ngx.location.capture('/metrics', { method = ngx.HTTP_GET, args = {} });
ngx.log(ngx.ERR, res.status);
if res.status == ngx.HTTP_OK then
  ngx.var.api_result = json_stripped2;
else
  ngx.log(ngx.STDERR, 'Lua Logger STDERR: header.lua exited');
  ngx.log(ngx.ERR, res.status);
  ngx.exit(403);
end
logger:info("Lua test END");

-- ngx.var.api_result = res.body;
