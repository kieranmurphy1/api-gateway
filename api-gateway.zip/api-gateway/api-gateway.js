// Declare dependencies
var express = require('express');
var app = express();
var bodyParser = require('body-parser');
// Parse JSON bodies for this app. Make sure you put
// `app.use(bodyParser.json())` **before** your route handlers!
app.use(bodyParser.json()); // support json encoded bodies
app.use(bodyParser.urlencoded({ extended: true })); // support encoded bodies

// Add some public routes that are accessible to everyone
app.get('/', function(req, res){
    res.send('<h1>Welcome to the Hompeage. <small>(Everyone can view this page)</small></h1>');
})

app.get('/about', function(req, res){
    res.send('<h1>Welcome to the about page<small>(Everyone can view this page)</small></h1>');
})

// Add some protected routes that only authenticated users will have access to
app.get('/api/leads', function(req, res){
    res.json({leads:[{id: 12345, name: 'ACME Corp'}, {id: 23456, name:'LeadGen'}, {id:45677, name: 'Organic Leads'}]})
})

app.get('/api/employees', function(req, res){
    res.json({employees:[{name: 'Ado Kukic', username:'@ado'}, {name: 'Diego Poza', username:'@tony'}, {name:'Prosper Otemuyiwa', username:'@unicodedeveloper'}, {name:'Sebastian Peyrott', username:'@speyrott'}, {name:'Kim Maida', username:'@kim.maida'}]})
})

app.get('/njs_jwt3', function(req, res){
    var fullUrl = req.protocol + '://' + req.get('host') + req.originalUrl;
    console.log("Request URL: " + fullUrl);
    console.log("Request Headers: " + JSON.stringify(req.headers));
    //console.log("Request Body: message = " + req.body.message);
    res.header('maximo_apiname','GetEmployees');
    res.json({employees:[{name: 'Ado Kukic', username:'@ado'}, {name: 'Diego Poza', username:'@tony'}, {name:'Prosper Otemuyiwa', username:'@unicodedeveloper'}, {name:'Sebastian Peyrott', username:'@speyrott'}, {name:'Kim Maida', username:'@kim.maida'}]})
})

app.get('/maximo/api/os/employees', function(req, res){
    var fullUrl = req.protocol + '://' + req.get('host') + req.originalUrl;
    console.log("------------------------------------------------------------------------------");
    console.log("Request URL: " + fullUrl);
    console.log("Request Headers: " + JSON.stringify(req.headers));    
    //console.log("Request Body: message = " + req.body.message);
    res.header('maximo_apiname','GetEmployees');
    res.json({employees:[{name: 'Ado Kukic', username:'@ado'}, {name: 'Diego Poza', username:'@tony'}, {name:'Prosper Otemuyiwa', username:'@unicodedeveloper'}, {name:'Sebastian Peyrott', username:'@speyrott'}, {name:'Kim Maida', username:'@kim.maida'}]})
})

app.get('/maximo/api/os/mxasset', function(req, res){
    var fullUrl = req.protocol + '://' + req.get('host') + req.originalUrl;
    console.log("------------------------------------------------------------------------------");
    console.log("Request URL: " + fullUrl);
    console.log("Request Headers: " + JSON.stringify(req.headers));    
    //console.log("Request Body: message = " + req.body.message);
    res.header('maximo_apiname','GetEmployees');
    res.json({employees:[{name: 'Ado Kukic', username:'@ado'}, {name: 'Diego Poza', username:'@tony'}, {name:'Prosper Otemuyiwa', username:'@unicodedeveloper'}, {name:'Sebastian Peyrott', username:'@speyrott'}, {name:'Kim Maida', username:'@kim.maida'}]})
})

app.get('/maximo/api/os/IWMWMGENAPIKEYTOKEN', function(req, res){
    var fullUrl = req.protocol + '://' + req.get('host') + req.originalUrl;
    console.log("------------------------------------------------------------------------------");
    console.log("Request URL: " + fullUrl);
    console.log("Request Headers: " + JSON.stringify(req.headers));
    //console.log("Request Body: message = " + req.body.message);
    res.header('maximo_apiname','GetEmployees');
    var delayInMilliseconds = 1000; //Artificial delay for testing
    setTimeout(function() {
        //res.status(404).send("api-gateway.js - Test Error on Maximo get operation")
        //res.send('<h1>Welcome to the Hompeage. <small>(Everyone can view this page)</small></h1>');
        res.json({"member":[{"_rowstamp":"186320977566992825","creationdate":"2022-04-30T12:55:58+01:00","apikey":"6nad6q7d","apikeytokenid":3755,"expiration":60,"href":"http:\/\/maximo-project2.vip.iwater.ie\/maximo\/api\/os\/iwmwmgenapikeytoken\/_Nm5hZDZxN2Q-","userid":"PCREWF19"}],"href":"http:\/\/maximo-project2.vip.iwater.ie\/maximo\/api\/os\/IWMWMGENAPIKEYTOKEN","responseInfo":{"href":"http:\/\/maximo_api_server\/maximo\/api\/os\/IWMWMGENAPIKEYTOKEN?oslc.select=*&oslc.where=userid=\"PCREWF19\"&lean=1"}})
       }, delayInMilliseconds);    
})

app.post('/maximo/api/os/IWMWMGENAPIKEYTOKEN', function(req, res){
    var fullUrl = req.protocol + '://' + req.get('host') + req.originalUrl;
    console.log("------------------------------------------------------------------------------");
    console.log("Request URL: " + fullUrl);
    console.log("Request Headers: " + JSON.stringify(req.headers));    
    //console.log("Request Body: message = " + req.body.message);
    res.header('maximo_apiname','GetEmployees');
    var delayInMilliseconds = 1000; //Artificial delay for testing
    setTimeout(function() {
        ////res.status(404).send("api-gateway.js - Test Error on Maximo Create operation")
        res.json({"userid":"PCREWF19","apikey":"6nad6q7d"})        
       }, delayInMilliseconds);    
})

app.delete('/maximo/api/os/IWMWMGENAPIKEYTOKEN/38144', function(req, res){
    var fullUrl = req.protocol + '://' + req.get('host') + req.originalUrl;
    console.log("------------------------------------------------------------------------------");
    console.log("Request URL: " + fullUrl);
    console.log("Request Headers: " + JSON.stringify(req.headers));
    //console.log("Request Body: message = " + req.body.message);
    res.header('maximo_apiname','DeleteEmployees');
    var delayInMilliseconds = 1000; //Artificial delay for testing
    setTimeout(function() {
        //res.status(404).send("api-gateway.js - Test Error on Maximo delete operation")
        res.json({"member":[{"_rowstamp":"186320977566992825","creationdate":"2022-04-30T12:55:58+01:00","apikey":"6nad6q7d","apikeytokenid":38144,"expiration":60,"href":"http:\/\/maximo-project2.vip.iwater.ie\/maximo\/api\/os\/iwmwmgenapikeytoken\/_Nm5hZDZxN2Q-","userid":"PCREWF19"}],"href":"http:\/\/maximo-project2.vip.iwater.ie\/maximo\/api\/os\/IWMWMGENAPIKEYTOKEN","responseInfo":{"href":"http:\/\/maximo_api_server\/maximo\/api\/os\/IWMWMGENAPIKEYTOKEN?oslc.select=*&oslc.where=userid=\"PCREWF19\"&lean=1"}})       
       }, delayInMilliseconds);    
})

app.get('/maximo/api/os/IWMWMWODETAILS', function(req, res){
    var fullUrl = req.protocol + '://' + req.get('host') + req.originalUrl;
    console.log("------------------------------------------------------------------------------");
    console.log("Request URL: " + fullUrl);
    console.log("Request Headers: " + JSON.stringify(req.headers));    
    //console.log("Request Body: message = " + req.body.message);
    res.header('maximo_apiname','GetEmployees');
    res.json({employees:[{name: 'Ado Kukic', username:'@ado'}, {name: 'Diego Poza', username:'@tony'}, {name:'Prosper Otemuyiwa', username:'@unicodedeveloper'}, {name:'Sebastian Peyrott', username:'@speyrott'}, {name:'Kim Maida', username:'@kim.maida'}]})
})

app.get('/maximo/api/os/IWMWMGVLDATA', function(req, res){
    var fullUrl = req.protocol + '://' + req.get('host') + req.originalUrl;
    console.log("------------------------------------------------------------------------------");
    console.log("Request URL: " + fullUrl);
    console.log("Request Headers: " + JSON.stringify(req.headers));
    //console.log("Request Body: message = " + req.body.message);
    res.header('maximo_apiname','GetEmployees');
    res.json({employees:[{name: 'Ado Kukic', username:'@ado'}, {name: 'Diego Poza', username:'@tony'}, {name:'Prosper Otemuyiwa', username:'@unicodedeveloper'}, {name:'Sebastian Peyrott', username:'@speyrott'}, {name:'Kim Maida', username:'@kim.maida'}]})
})

app.post('/auth/realms/dev/protocol/openid-connect/token/introspect', function(req, res){
    var fullUrl = req.protocol + '://' + req.get('host') + req.originalUrl;
    console.log("------------------------------------------------------------------------------");
    console.log("Request URL: " + fullUrl);
    console.log("Request Headers: " + JSON.stringify(req.headers));
    console.log("Request Body: token_type_hint = " + req.body.token_type_hint);
    console.log("Request Body: token = " + req.body.token);
    res.header('JWT_validation','ValidateToken');
    res.json({"active":false})
})

app.listen(9000);
